<?php // login.php
  $hn = 'localhost';
  $db = 'petbook';
  $un = 'root';
  $pw = '';
?>
